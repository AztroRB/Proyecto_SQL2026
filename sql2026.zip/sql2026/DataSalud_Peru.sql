SELECT *
FROM audit.LoteCarga
ORDER BY lote_id DESC;